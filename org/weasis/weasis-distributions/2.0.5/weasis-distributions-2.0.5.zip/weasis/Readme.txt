The Weasis DICOM viewer requires that a Java Runtime Environment (JRE 6 update 10 or greater) be installed on your machine to run.

For more information about the viewer go to http://www.dcm4che.org/confluence/display/WEA/Home.